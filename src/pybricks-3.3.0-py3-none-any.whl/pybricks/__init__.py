from typing import Tuple


version: Tuple[str, str, str] = (
    "hub",
    "3.X.YbZ",
    "v3.X.YbZ-GIT_HASH on DATE",
)
